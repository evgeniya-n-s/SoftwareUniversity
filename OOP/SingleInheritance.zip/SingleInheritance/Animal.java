package SingleInheritance;

public class Animal {

    public void eat(){
        System.out.println ("eating...");
    }
}

