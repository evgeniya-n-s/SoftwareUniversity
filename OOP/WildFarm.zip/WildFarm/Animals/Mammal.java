package WildFarm.Animals;

public abstract class Mammal extends Animal{

    protected Mammal(String animalName, String animalType, Double animalWeight,String livingRegion) {
        super ( animalName, animalType, animalWeight,livingRegion );
    }

}
