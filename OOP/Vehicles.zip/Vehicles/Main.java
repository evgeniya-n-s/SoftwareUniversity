package Vehicles;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner ( System.in );

        String[] tokens = scanner.nextLine ().split ( "\\s+" );

        Vehicle car = new Car ( Double.parseDouble ( tokens[1]),Double.parseDouble ( tokens[2] ) );
        tokens = scanner.nextLine ().split ( "\\s+" );

        Vehicle truck = new Truck ( Double.parseDouble ( tokens[1]),Double.parseDouble ( tokens[2] ) );

        int commands = Integer.parseInt ( scanner.nextLine () );

        while (commands -->0){
            String command = scanner.nextLine ();
            String[] params = command.split ( "\\s+" );
            double arguments = Double.parseDouble ( params[2] );

            if(command.contains ( "Drive" )){
                if(params[1].equals ( "Car" )){
                    System.out.println (car.drive ( arguments ));
                } else {
                    System.out.println (truck.drive ( arguments ));
                }
            }else {
                if(params[1].equals ( "Car" )){
                    car.refuel ( arguments );
                } else {
                    truck.refuel ( arguments );
                }
            }
        }
        System.out.println (car.toString ());
        System.out.println (truck.toString ());
    }
}
