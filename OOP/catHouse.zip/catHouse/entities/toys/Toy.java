package catHouse.entities.toys;

public interface Toy {
    int getSoftness();

    double getPrice();
}
