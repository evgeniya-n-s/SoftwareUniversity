package catHouse.entities.toys;

public class Ball extends BaseToy{
    private static final int DEFAULT_SOFTNESS = 1;
    private static final int DEFAULT_PRICE = 10;
    public Ball() {
        super(DEFAULT_SOFTNESS,DEFAULT_PRICE);
    }
}
