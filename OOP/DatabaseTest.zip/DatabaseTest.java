package p01_Database;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.naming.OperationNotSupportedException;

import static org.junit.Assert.*;

public class DatabaseTest {

    private Database database;
    private static final Integer[] NUMBERS = {5, 9, 29, 45};

    @Before
    public void prepareDatabase () throws OperationNotSupportedException {
        database = new Database(NUMBERS);
    }

    //Constructor Testing
    //1.връща ли правилен обект -> елементите и брой на елементите
    @Test
    public void testConstructorHasToCreateValidObject () throws OperationNotSupportedException {
        Integer [] databaseNumbers = database.getElements();
        //ЕЛЕМЕНТИТЕ
        //БРОЙ НА ЕЛЕМЕНТИТЕ
        Assert.assertEquals("Count of elements is incorrect", NUMBERS.length, databaseNumbers.length);
        for (int i = 0; i < databaseNumbers.length; i++) {
            Assert.assertEquals(NUMBERS[i], databaseNumbers[i]);
        }
    }
    //2. случай елемените са над 16
    @Test(expected = OperationNotSupportedException.class)
    public void testConstructorThrowWhenUseMoreThanSixteenElements () throws OperationNotSupportedException {
        Integer[] numbers = new Integer[17];
        new Database(numbers);
    }
    //3. случай елементите са под 1
    @Test(expected = OperationNotSupportedException.class)
    public void testConstructorThrowWhenUseLessThanOneElement () throws OperationNotSupportedException {
        Integer[] numbers = new Integer[0];
        new Database(numbers);
    }

    //Add method testing

    //1. подаване на null елемент
    @Test(expected = OperationNotSupportedException.class)
    public void testAddShouldThrowExWhenParamNull () throws OperationNotSupportedException {
        database.add(null);
    }

    //2. правилна работа, добавя елемента в масива
    @Test
    public void testAddShouldAddElement () throws OperationNotSupportedException {
        database.add(17);
        //5, 9, 29, 45, 17
        Assert.assertEquals(5, database.getElements().length);
        Assert.assertEquals(Integer.valueOf(17), database.getElements()[4]);
    }

    //Remove method testing
    //1. нямаме елементи
    @Test (expected = OperationNotSupportedException.class)
    public void testRemoveShouldThrowExWithEmptyData () throws OperationNotSupportedException {
        for (int i = 0; i < NUMBERS.length; i++) {
            database.remove();
        }
        //{} празен масив
        database.remove();
    }
    //2. дали премахва последния елемент
    @Test
    public void testRemoveLastElement () throws OperationNotSupportedException {
        database.remove();
        Integer [] elementsInDatabase = database.getElements();
        Assert.assertEquals(NUMBERS.length - 1, elementsInDatabase.length);
        Assert.assertEquals(Integer.valueOf(29), elementsInDatabase[elementsInDatabase.length - 1]);
        for (int i = 0; i < elementsInDatabase.length; i++) {
            Assert.assertEquals(elementsInDatabase[i], NUMBERS[i]);
        }
    }

}