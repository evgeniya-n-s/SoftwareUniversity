package Telephony2;

public interface Browsable {
    String browse();
}
