package Telephony2;

public interface Callable {
    String call();
}
