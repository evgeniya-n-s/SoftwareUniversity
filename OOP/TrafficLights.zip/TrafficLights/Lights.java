package TrafficLights;

public enum Lights {
    RED,
    GREEN,
    YELLOW;
}
