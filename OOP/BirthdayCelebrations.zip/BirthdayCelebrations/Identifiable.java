package BirthdayCelebrations;

public interface Identifiable {
    String getId();
}
