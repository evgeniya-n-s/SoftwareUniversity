package BirthdayCelebrations;

public interface Creatures {
    String getName();
}
