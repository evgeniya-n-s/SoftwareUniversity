package BirthdayCelebrations;

public interface Person {
    int getAge();
}
