package BirthdayCelebrations;

public interface Machine {
    String getModel();
}
