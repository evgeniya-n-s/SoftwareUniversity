package GenericBox;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner ( System.in );

        int n = Integer.parseInt ( scanner.nextLine () );

        Box<Double> box = new Box<> ();
        for (int i = 0; i < n; i++) {
            double text = Double.parseDouble ( scanner.nextLine ());
            box.add ( text );
        }

        double elementCompare = Double.parseDouble ( scanner.nextLine ());

        double countGreater = box.countGreater ( elementCompare );

//        String[] tokens = scanner.nextLine ().split ( "\\s+" );
//        Integer firstIndex = Integer.parseInt ( tokens[0] );
//        Integer secondIndex = Integer.parseInt ( tokens[1] );
//
//        box.swap ( firstIndex, secondIndex );

        System.out.println ( String.format ( "%.0f",countGreater));
    }
}
